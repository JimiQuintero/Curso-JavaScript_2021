export default {
  public: "Your Public Key",
  secret: "Your Secret Key",
};
