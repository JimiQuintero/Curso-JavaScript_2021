/* **********     Curso JavaScript: 33. Módulos ( import / export ) - #jonmircha     ********** */
console.log("Mi navegador no soporta Módulos +ES6");
