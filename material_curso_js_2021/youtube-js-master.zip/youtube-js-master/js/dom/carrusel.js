/* **********     Curso JavaScript: 98. DOM: Ejercicios Prácticos | Responsive Slider - #jonmircha     ********** */
